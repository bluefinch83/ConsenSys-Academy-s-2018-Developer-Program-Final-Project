var BattleShip = artifacts.require("./BattleShip.sol");

module.exports = function(deployer) {
  deployer.deploy(BattleShip);
};
